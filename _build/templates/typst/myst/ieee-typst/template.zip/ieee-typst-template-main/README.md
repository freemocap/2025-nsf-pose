# IEEE Typst MyST Template

A port of the [Typst IEEE template](https://github.com/typst/templates/tree/main/ieee) with minimal modifications. The `main.typ` file has been updated to allow `myst-templates + jtex` to fill in data from `MyST`.

This template includes very minimal features from MyST; hopefully it provides a basis to create more complex templates.

[](thumbnail.png)

- Author: Typst
- Author Website: https://typst.app/
- License: Unlicense